from setuptools import setup

setup(name='ipython_magic_folium',
	install_requires=['folium','fiona'],
      packages=['folium_magic']
)